package huffman;

import java.util.logging.Logger;

public class Constants {
	public static final String PROGRAM_NAME = "huffman";
	public static final Logger LOGGER = Logger.getLogger(PROGRAM_NAME);
	public static final int NUM_CHARS = 256;
}

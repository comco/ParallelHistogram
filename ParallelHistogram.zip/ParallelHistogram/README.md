ParallelHistogram
=================

A java implementation of parallel histograms
